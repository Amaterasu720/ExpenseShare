package com.developer.maanavshah.billsplitter.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Bill {
    public static final String TAG = "Bill";

    private long id;
    private String billName;
    private double billAmount;
    private double billShare;
    private String billMembers;
    private long tripId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return billName;
    }

    public void setName(String billName) {
        this.billName = billName;
    }

    public double getBillAmount() {
        Double toBeTruncated = billAmount;
        Double truncatedDouble = BigDecimal.valueOf(toBeTruncated)
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
        billAmount = truncatedDouble;return billAmount;
    }

    public void setBillAmount(double billAmount) {
        Double toBeTruncated = billAmount;
        Double truncatedDouble = BigDecimal.valueOf(toBeTruncated)
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
        billAmount = truncatedDouble;
        this.billAmount = billAmount;
    }

    public double getBillShare() {
        Double toBeTruncated = billShare;
        Double truncatedDouble = BigDecimal.valueOf(toBeTruncated)
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
        billShare = truncatedDouble;
        return billShare;
    }

    public void setBillShare(double billAmount) {
        Double toBeTruncated = billAmount;
        Double truncatedDouble = BigDecimal.valueOf(toBeTruncated)
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
        billAmount = truncatedDouble;
        this.billShare = billAmount;
    }

    public String getBillMembers() {
        return billMembers;
    }

    public void setBillMembers(String billAmount) {
        this.billMembers = billAmount;
    }

    public long getTripId() {
        return tripId;
    }

    public void setTripId(long tripId) {
        this.tripId = tripId;
    }
}
